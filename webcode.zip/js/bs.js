let limit_count = 0; //JS에서 변수값 저장 가능
let count = 0;
let strike = 0;
let ball = 0;
let tryList = [];
const correctList = [];
function setLevel(level){
    let start = document.getElementById('start');
    start.disabled = false;
    limit_count = level;
    registEvent();
    randomNum();
    alert(correctList);
    // let stop = document.getElementById('stop');
    // stop.disabled = false;
}

function start(flag){
    let play = document.getElementById('play');
    if(flag){
        play.style.display = 'block';
    } else{
        play.style.display = 'none';
    }
}

function handout(){
    let strike = document.getElementById('strike');
    let ball = document.getElementById('ball');

    let result = strike.innerHTML + '-' + ball.innerHTML;

    let tried = document.getElementById('tried');
    tried.innerHTML += '<br>' + result; // 한칸씩 뛰우기

    count += 1;

    if(count==limit_count){
        alert('모든 사용횟수를 사용했습니다.');
        let btn = document.getElementById('btn_handout');
        btn.disabled = true;
    }
}

function registEvent(){
    let imgs = document.getElementsByClassName('selectNum');
    for(let i=0;i<imgs.length;i++){
        imgs[i].addEventListener('click',function(event){ //이벤트 리스너
            if(tryList.length==0 && event.target.alt == 0){
                alert("첫번재 숫자에 0을 입력할 수 없습니다");
            } else{
                tryList.push(event.target.alt);
            }
            if(tryList.length==4){
                //removeEvent();
                let addTryList = document.getElementById("tried");
                addTryList.innerHTML += '<br>' + tryList;

                compareList();

                for(let i=0;i<4;i++){
                    delete tryList[i];
                }
                alert(tryList);
            }
        });
    }
    alert('이벤트가 등록되었습니다');
}

function removeEvent(){
    let imgs = document.getElementsByClassName('selectNum');
    for(let i=0;i<imgs.length;i++){
        imgs[i].removeEventListener('click',()=>{ //이벤트 리스너
        });
    }

    alert(tryList);
}

function randomNum(){
    const numList = [0,1,2,3,4,5,6,7,8,9];
    
    let num = 0;
    for(let i=0;i<4;i++){
        num = Math.floor(Math.random() * (i==0 ? 8 : 9-i)) + (i==0 ? 1 : 0);
        correctList.push(numList.splice(num,1));
    }

    for(let i=0;i < correctList.length;i++){
        console.log(correctList[i]);
    }
}

function compareList(){
    for(let i=0;i<4;i++){
        console.log(1);
        
        if(correctList.includes(tryList[i].toString())){//includes indexOf 둘다 안됨 이유 모름
            console.log(2);
            if(correctList[i]==tryList[i]){
                console.log(3);
                strike += 1;
            } else {
                ball += 1;
            }
        }
    }
    alert(strike+'-'+ball);
    strike = 0;
    ball = 0;
}